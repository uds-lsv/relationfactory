{-# LANGUAGE BangPatterns #-}
module Helper.RecipRank (recipRanks,mrr,mean)
where

import Data.List (foldl')
import Debug.Trace

type RecipRank = Double

recipRanks :: (Eq y) => [(y,[y])] -> [RecipRank]
recipRanks xys = map (uncurry f) xys
    where f y ys = case [ r | (r,y') <- zip [1..] ys , y' == y ] of
                     []  -> 0
                     r:_ -> 1/r

mean :: (RealFrac n) => [n] -> n
mean xs = let (sum,len) = foldl' (\(!s,!l) x -> (if round l `rem` 10000 == 0
                                                 then trace (show $ s/l)
                                                 else id) 
                                                 (s+x,l+1)) 
                          (0,0) 
                          xs
          in sum/len

mrr :: (Eq y) => [(y,[y])] -> RecipRank
mrr = mean . recipRanks
