char *ghc_rts_opts = "-K100m -H500m";
