{-# LANGUAGE NoMonomorphismRestriction #-}
module Config 
    ( Config (..), Flags(..) )
where
import Data.Char
import Helper.Atom (AtomTable)
import qualified Data.Binary as B
import Control.Monad (ap)
import FeatureTemplate (Feature)


data Flags = Flags { flagRate          :: !Float
                   , flagBeam          :: !Int
                   , flagIter          :: !Int
                   , flagMinFeatCount  :: !Int
                   , flagHeldout     :: Maybe FilePath
                   , flagHash        :: !Bool
                   , flagHashSample  :: !Int
                   , flagHashMaxSize :: Maybe Int
                   } 

data Config = Config { atomTable :: AtomTable 
                     , featureTemplate :: Feature
                     , flags :: Flags
                     , fieldNum :: !Int
                     }

instance B.Binary Flags where
    get = do (f1,f2,f3,f4,f5,f6,f7,f8) <- B.get
             return $ Flags f1 f2 f3 f4 f5 f6 f7 f8
    put (Flags f1 f2 f3 f4 f5 f6 f7 f8) = B.put (f1,f2,f3,f4,f5,f6,f7,f8)

instance B.Binary Config where
    get = let g = B.get
          in return Config `ap` g `ap` g `ap` g `ap` g

    put (Config a b c d) =
        let p = B.put 
        in p a >> p b >> p c >> p d
