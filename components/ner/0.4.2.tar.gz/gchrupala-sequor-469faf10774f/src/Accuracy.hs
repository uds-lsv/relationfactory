{-# LANGUAGE BangPatterns #-}
import Text.Printf (printf)
import Data.List (foldl')
import qualified Data.ByteString.Lazy.Char8 as T

main :: IO ()
main = putStr . accuracy =<< T.getContents

accuracy :: T.ByteString -> String
accuracy = 
    printf "%.5f\n" 
    . (\(s,l) -> s/l::Double)
    . foldl' (\(!s,!l) !x -> (s+x,l+1)) (0,0)
    . map (\[a,b] -> if a == b then 1 else 0)
    . filter (not . null)
    . map T.words
    . T.lines
